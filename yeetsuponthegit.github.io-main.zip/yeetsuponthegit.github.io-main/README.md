# Lol this is my website :)


---
it uses the [google fonts](https://fonts.google.com "google fonts this way") library that way it can load fonts without needing the user to have them installed. ~~It also uses a [live markdown translator](https://md-block.verou.me/ "its called 'md-block'. We stopped using it because it doesnt work on older devices.") for quality-of-life and to edit pages faster~~ I stopped using a live MD translator, as it does not work on older systems. See, my mission is to create a meme site that can be quickly accessed on almost any device with a web browser, new *and* old. To keep things simple, I'm trying to use code compatible with at least any old windows XP, OS X, iOS 6, and Android 4 system. This site was originally developed using the [default chromeOS text editor](https://github.com/GoogleChromeLabs/text-app "You've been banished to the google chrome text app repo"), [ChromeOS 72](https://chromereleases.googleblog.com/2019/02/stable-channel-update-for-chrome-os.html "Get google blogged"), [Crouton](https://github.com/dnschneid/crouton "Look, a dead Linux on chromebooks thing!") and an [HP CB2 chromebook (2013? I think?)](https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://www.amazon.com/HP-Chromebook-11-1101-White-Blue/dp/B00FJXVRM8&ved=2ahUKEwj3ncH9puCEAxUVLtAFHVxTAYoQFnoECDQQAQ&usg=AOvVaw1L2ER1v4WkBOxi9Rbm-joW "amazon page for the dead thing") with write protect disable (chromeos nerds know what I'm talking about). I recently migrated over to the github web client and vsc(visual studio) for ubuntu and here we are today. I hope you have fun seeing my memes and don't try to hack the source code or I will pull up your ip and dns and pin it to my wall of shame.

you can read the [`how it's made™`](https://github.com/YeetsupOntheGit/yeetsuponthegit.github.io/tree/main/how%20it's%20made%E2%84%A2) folder for more info.

---
### colors used (in HEX):
body(background): `#00051f`

body(text): `#d9f1ff`

links(not hovering): `#667dff`

links(hovering): `#052bff`  

---
### fonts used (google fonts):
headings/titles: [open sans *(weight: 800 extra bold)*](https://fonts.google.com/specimen/Open+Sans)  

body/main font: [montserrat *(weight: 500 medium)*](https://fonts.google.com/specimen/Montserrat)  

--- 
### Submit memes
[via email](mailto:itsyeetsup@gmail.com?subject=I%20wanna%20submit%20a%20meme)

[in the discord](https://discord.gg/BCfw8dbESV)
