# \*dramatic intro\*
### July 2023 

---
Two things happened: 
1. fuck you,
2. and I opened the default system notepad because I was bored.

You see, I had a chromebook that was just a *little* old. It released in spring 2013, and it would've only been a decade old at that point. nevertheless it was useless [get cliffhangered]
